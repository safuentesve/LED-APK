# LED Panel Controller — Pasos para compilar el APK

## Archivos del proyecto
```
led_panel_app/
├── main.py           ← código principal de la app
├── buildozer.spec    ← configuración de compilación
└── PASOS_COMPILAR.md ← esta guía
```

---

## OPCIÓN A — Compilar en Linux / WSL (recomendado)

### Paso 1 — Instalar dependencias del sistema
```bash
sudo apt update
sudo apt install -y \
    python3 python3-pip \
    git zip unzip \
    openjdk-17-jdk \
    build-essential \
    libssl-dev libffi-dev \
    autoconf libtool pkg-config \
    zlib1g-dev libncurses5-dev \
    libsqlite3-dev libreadline-dev
```

### Paso 2 — Instalar buildozer y dependencias Python
```bash
pip3 install --upgrade buildozer cython
pip3 install kivy==2.3.0 kivymd==1.1.1
```

### Paso 3 — Colocar los archivos del proyecto
```bash
mkdir -p ~/led_panel_app
cd ~/led_panel_app
# Copiar main.py y buildozer.spec aquí
```

### Paso 4 — Compilar el APK (debug, para probar)
```bash
cd ~/led_panel_app
buildozer android debug
```
El primer build tarda 15-40 min (descarga SDK, NDK, etc.).
El APK queda en: `bin/ledpanelcontroller-1.0-debug.apk`

### Paso 5 — Instalar en el teléfono
```bash
# Con USB conectado y depuración USB activada:
adb install bin/ledpanelcontroller-1.0-debug.apk

# O simplemente copia el APK al teléfono y ábrelo
```

---

## OPCIÓN B — Google Colab (sin instalar nada local)

Crea un notebook en https://colab.research.google.com y ejecuta:

```python
# Celda 1: Instalar buildozer
!pip install buildozer cython
!apt-get install -y \
    python3-pip build-essential git \
    libssl-dev libffi-dev zlib1g-dev \
    openjdk-17-jdk

# Celda 2: Subir archivos
from google.colab import files
files.upload()   # sube main.py y buildozer.spec

# Celda 3: Compilar
!buildozer android debug 2>&1 | tail -50

# Celda 4: Descargar el APK
import os, glob
apk = glob.glob('bin/*.apk')[0]
files.download(apk)
```

---

## OPCIÓN C — GitHub Actions (100% automático en la nube)

1. Crea un repositorio en GitHub con los archivos `main.py` y `buildozer.spec`
2. Crea el archivo `.github/workflows/build.yml`:

```yaml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.10'
      - name: Install buildozer
        run: |
          pip install buildozer cython
          sudo apt install -y openjdk-17-jdk \
            build-essential libssl-dev libffi-dev zlib1g-dev
      - name: Build APK
        run: buildozer android debug
      - uses: actions/upload-artifact@v3
        with:
          name: led-panel-apk
          path: bin/*.apk
```

3. Haz push → el APK aparece en la pestaña "Artifacts" de Actions.

---

## Instalar en Android

1. Copia el APK al teléfono (USB, Google Drive, WhatsApp, etc.)
2. En Ajustes → Seguridad → activa **"Orígenes desconocidos"** (o "Instalar apps desconocidas")
3. Abre el APK desde el gestor de archivos
4. Acepta los permisos de Bluetooth y Ubicación cuando la app los pida

---

## Solución de errores comunes

| Error | Solución |
|-------|----------|
| `SDK license not accepted` | Agrega `android.accept_sdk_license = True` en buildozer.spec |
| `NDK not found` | Buildozer lo descarga automáticamente; asegúrate de tener conexión |
| `cython error` | `pip install --upgrade cython` |
| `JAVA_HOME not set` | `export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64` |
| App crashea al abrir | Revisa logs con `adb logcat | grep python` |
| No encuentra el panel BLE | Asegúrate de dar permiso de Ubicación (obligatorio para BLE en Android < 12) |
